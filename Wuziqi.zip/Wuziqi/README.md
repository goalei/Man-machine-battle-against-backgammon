# AI
基于Alpha-Beta剪枝博弈树的五子棋AI算法实现。

附加功能：截图保存

相应技术博客：http://zhaidongyan.cn/alpha-beta-AIWuziqi/

软件运行截图：
![screenshot](https://github.com/rockzhai/AI-Wuziqi/blob/master/screenshot.png)
